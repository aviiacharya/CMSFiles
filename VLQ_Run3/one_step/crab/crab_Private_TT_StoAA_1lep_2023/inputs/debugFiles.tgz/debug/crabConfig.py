from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Private_TT_StoAA_1lep_2023'
config.General.workArea = 'crab'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.maxMemoryMB = 8000
config.JobType.sendExternalFolder = True
config.JobType.eventsPerLumi = 1000
config.JobType.scriptExe = 'exe_2023.sh'
config.JobType.psetName = 'FAKENanoAODv12_cfg.py'
config.JobType.pluginName = 'PrivateMC'
config.JobType.allowUndistributedCMSSW = True
config.JobType.numCores = 4
config.JobType.inputFiles = ['FrameworkJobReport.xml', 'inputs', 'TT_StoAA_1lep_slc7_amd64_gcc10_CMSSW_12_4_8_tarball.tar.xz']
config.JobType.scriptArgs = ['nevent=1000', 'nthread=4', 'procname=TT_StoAA_1lep_cfg', 'beginseed=0']
config.section_('Data')
config.Data.totalUnits = 20000
config.Data.unitsPerJob = 1000
config.Data.outputDatasetTag = 'PrivateMC'
config.Data.splitting = 'EventBased'
config.Data.outLFNDirBase = '/store/user/abachary/TTtoSStt/Y2023/TT_StoAA_1lep'
config.Data.outputPrimaryDataset = 'TT_StoAA_1lep'
config.Data.inputDBS = 'global'
config.Data.publication = True
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T3_US_FNALLPC'
